<?php

return [
    'name' => 'Loan'
];
