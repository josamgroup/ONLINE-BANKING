<?php

namespace Modules\Loan\Entities;

use Illuminate\Database\Eloquent\Model;

class LoanDisbursementChannel extends Model
{
    protected $fillable = [];
}
