<?php

namespace Modules\Loan\Entities;

use Illuminate\Database\Eloquent\Model;

class LoanOfficerHistory extends Model
{
    protected $fillable = [];
    public $table = "loan_officer_history";
}
