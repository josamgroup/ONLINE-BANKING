<?php

namespace Modules\Loan\Http\Controllers;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Auth;
use Laracasts\Flash\Flash;
use Modules\Core\Entities\Currency;
use Modules\Loan\Entities\Fund;
use Modules\Loan\Entities\LoanWallets;
//use Illuminate\Support\Facades\DB
use DB;
use Yajra\DataTables\Facades\DataTables;

class LoanWalletsController extends Controller
{
    public function __construct()
    {
        $this->middleware(['auth', '2fa']);
        $this->middleware(['permission:loan.loans.charges.index'])->only(['index', 'show']);
        $this->middleware(['permission:loan.loans.charges.create'])->only(['create', 'store']);
        $this->middleware(['permission:loan.loans.charges.edit'])->only(['edit', 'update']);
        $this->middleware(['permission:loan.loans.charges.destroy'])->only(['destroy']);

    }

    /**
     * Display a listing of the resource.
     * @return Response
     */






    public function index(Request $request)
    {
        $perPage = $request->per_page ?: 20;
        $orderBy = $request->order_by;
        $orderByDir = $request->order_by_dir;
        $search = $request->s;
        $data = LoanWallets::latest()
            ->when($orderBy, function (Builder $query) use ($orderBy, $orderByDir) {
                $query->orderBy($orderBy, $orderByDir);
            })
            ->when($search, function (Builder $query) use ($search) {
                $query->where('WalletID', 'like', "%$search%");
                $query->orWhere('AccountID', 'like', "%$search%");
                $query->orWhere('balance', 'like', "%$search%");
                $query->orWhere('created_at', 'like', "%$search%");
              
            })
            ->paginate($perPage)
            ->appends($request->input());
        return theme_view('loan::loan_wallet.index',compact('data'));
    }

   




    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'rate_id' => ['required'],
            'lower' => ['required'],
            'upper' => ['required'],
            'rate' => ['required'],
        ]);
        $loan_charge = new LoanWallets();
        $loan_charge->created_by_id = Auth::id();
        $loan_charge->currency_id = $request->currency_id;
        $loan_charge->loan_charge_type_id = $request->loan_charge_type_id;
        $loan_charge->loan_charge_option_id = $request->loan_charge_option_id;
        $loan_charge->name = $request->name;
        $loan_charge->amount = $request->amount;
        $loan_charge->is_penalty = $request->is_penalty;
        $loan_charge->active = $request->active;
        $loan_charge->allow_override = $request->allow_override;
        $loan_charge->save();
        activity()->on($loan_charge)
            ->withProperties(['id' => $loan_charge->id])
            ->log('Create Loan Rate');
        \flash(trans_choice("core::general.successfully_saved", 1))->success()->important();
        return redirect('loan/wallets');
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Response
     */
    public function show($id)
    {
        $rate = LoanRates::find($id);
        return theme_view('loan::loan_wallet.show', compact('rate'));
    }

    /**
     * Show the form for editing the specified resource.
     * @param int $id
     * @return Response
     */
    public function edit($id)
    {
        $loan_wallet =DB::table('client_wallets')->where('WalletID', $id)->first(); //LoanRate::find($id);
        return theme_view('loan::loan_wallet.edit', compact('loan_wallet'));
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'AccountID' => ['required'],
            'current' => ['required'],
            'balance' => ['required'],
            
        ]);
        $loan_wallet =DB::table('client_wallets')->where('AccountID', $request->AccountID)->first();// LoanRates::find($id);
        ///print_r($loan_wallet);exit;
        $current =(int)$loan_wallet->balance + (int)$request->balance;
        $wallet =DB::table('client_wallets')->where('AccountID', $request->AccountID)->update(['balance' =>DB::raw($current)]);
        // $current =(int)$loan_wallet->balance + (int)$request->balance;
        // $wallet =DB::statement("UPDATE client_wallets SET balance =".$current."  where AccountID = ".$request->AccountID." ");
        // $loan_wallet->balance = 
        // $loan_wallet->save();
        // activity()->on($loan_wallet)
        //     ->withProperties(['id' => $loan_wallet->WalletID])
        //     ->log('Update Loan wallets');
        \flash(trans_choice("core::general.successfully_saved", 1))->success()->important();
        return redirect('loan/wallets');
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Response
     */
    public function destroy($id)
    {
        $loan_charge = LoanRates::find($id);
        $loan_charge->delete();
        activity()->on($loan_charge)
            ->withProperties(['id' => $loan_charge->rate_id])
            ->log('Delete Loan Rate');
        \flash(trans_choice("core::general.successfully_deleted", 1))->success()->important();
        return redirect()->back();
    }
}
